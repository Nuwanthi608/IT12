<?php
include 'db_connect.php';
$message = "";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    // Get form data
    $st_name = $_POST['st_name'];
    $username = $_POST['username'];
    $email = $_POST['email'];
    $dep_id = $_POST['dep_id'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    // Get department name
    $dep_query = $conn->query("SELECT name FROM department WHERE dep_id = '$dep_id'");
    $dep_row = $dep_query->fetch_assoc();
    $dep_name = $dep_row['name'];

    // Insert to DB
    $sql = "INSERT INTO student (st_name, username, email, dep_id, dep_name, password)
            VALUES ('$st_name', '$username', '$email', '$dep_id', '$dep_name', '$password')";

    if ($conn->query($sql)) {
    echo "<script>
            setTimeout(function() {
                alert('Signup successful! Welcome aboard! 🎉');
                window.location.href='login.php';
            }, 100);
          </script>";
    exit();
} else {
    $message = 'Error: ' . $conn->error;
}

}


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Register - Face Recognition System</title>
    <link rel="stylesheet" href="register.css" />
    <link rel="stylesheet" href="index.css">
</head>
<body>
        <!-- Navigation Bar -->
    <nav class="navbar">
        <div class="nav-container">
            <div class="logo">FACE</div>
            <ul class="nav-menu">
                <li><a href="index.html" class="nav-link active">Home</a></li>
                <li><a href="login.php" class="nav-link">Login</a></li>
                <li><a href="register.php" class="nav-link">Register</a></li>
                <li><a href="dashboard.html" class="nav-link">Dashboard</a></li>
                <li><a href="capture.html" class="nav-link">Face Capture</a></li>
            </ul>
            <div class="hamburger">
                <span></span>
                <span></span>
                <span></span>
            </div>
        </div>
    </nav>
    <main class="page">
        <section class="visual">
            <div class="logo">FACE</div>
            <h1>Join Our Community</h1>
            <p class="lead">Create an account to start using the Face Recognition System and manage your events with ease!</p>

            <div class="decor">
                <span class="dot a"></span>
                <span class="dot b"></span>
                <span class="dot c"></span>
            </div>
        </section>

        <section class="auth">
            <!-- IMPORTANT: method + action added -->
            <form id="registerForm" method="POST" action="" class="card" autocomplete="on" novalidate>
                <div class="card-head">
                    <h2>Create Account</h2>
                    <p class="muted">Fill in your details to get started</p>
                </div>

                <label class="field">
                    <span class="label-text">Full Name</span>
                    <input id="fullname" name="st_name" type="text" placeholder="John Doe" required />
                </label>

                <label class="field">
                    <span class="label-text">Username</span>
                    <input id="username" name="username" type="text" placeholder="johndoe" required minlength="4" />
                </label>

                <label class="field">
                    <span class="label-text">Email Address</span>
                    <input id="email" name="email" type="email" placeholder="you@example.com" required />
                </label>

                <label class="field">
                    <span class="dep">Department</span>
                    <!-- FIXED name="dep_id" -->
                    <select name="dep_id" required>
                        <option value="">-- Select Department --</option>
                        <?php
                        $deps = $conn->query("SELECT dep_id, name FROM department");
                        while ($d = $deps->fetch_assoc()) {
                            echo "<option value='{$d['dep_id']}'>{$d['name']}</option>";
                        }
                        ?>
                    </select>
                </label>

                <label class="field">
                    <span class="label-text">Password</span>
                    <div class="pw-wrap">
                        <input id="password" name="password" type="password" placeholder="Enter password" required minlength="8" />
                        <button type="button" class="pw-toggle" aria-label="Show password">👁️</button>
                    </div>
                </label>

                <label class="field">
                    <span class="label-text">Confirm Password</span>
                    <div class="pw-wrap">
                        <input id="confirmPassword" name="confirmPassword" type="password" placeholder="Confirm password" required minlength="8" />
                        <button type="button" class="pw-toggle-confirm" aria-label="Show password">👁️</button>
                    </div>
                </label>

                <div class="terms">
                    <label class="checkbox">
                        <input type="checkbox" name="terms" required /> I agree to the <a href="#">Terms of Service</a>
                    </label>
                </div>

                <button type="submit" class="btn primary">Create Account</button>

                <p class="signin">Already have an account? <a href="login.html">Sign In</a></p>
                <p class="message"><?php echo $message; ?></p>
            </form>
        </section>
    </main>

        <!-- Footer -->
    <footer class="footer">
        <div class="footer-content">
            <p>&copy; 2025 Face Recognition System | All Rights Reserved</p>
            
        </div>
    </footer>

    <script>
        (function(){
            const pwToggle = document.querySelector('.pw-toggle');
            const pwInput = document.getElementById('password');
            pwToggle?.addEventListener('click', ()=> {
                const t = pwInput.type === 'password' ? 'text' : 'password';
                pwInput.type = t;
                pwToggle.textContent = t === 'text' ? '🙈' : '👁️';
            });

            const pwToggleConfirm = document.querySelector('.pw-toggle-confirm');
            const pwInputConfirm = document.getElementById('confirmPassword');
            pwToggleConfirm?.addEventListener('click', ()=> {
                const t = pwInputConfirm.type === 'password' ? 'text' : 'password';
                pwInputConfirm.type = t;
                pwToggleConfirm.textContent = t === 'text' ? '🙈' : '👁️';
            });

            const form = document.getElementById('registerForm');

            form?.addEventListener('submit', (e)=>{
                const password = document.getElementById('password').value;
                const confirmPassword = document.getElementById('confirmPassword').value;

                if (password !== confirmPassword) {
                    e.preventDefault();
                    alert('Passwords do not match!');
                }

                // Let the form submit normally now!
            });
        })();
    </script>
</body>
</html>
