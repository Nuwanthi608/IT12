<?php
session_start();
include 'db_connect.php';

$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = trim($_POST["email"]);
    $password = trim($_POST["password"]);

    $sql = "SELECT * FROM admin_users WHERE email='$email'";
    $res = $conn->query($sql);

    if ($res->num_rows > 0) {
        $row = $res->fetch_assoc();

        if (password_verify($password, $row["password"])) {
            $_SESSION["admin_id"] = $row["admin_id"];
            $_SESSION["username"] = $row["username"];

            echo "<script>
                    alert('Admin Login Successful!');
                    window.location='admin_dashboard.php';
                  </script>";
            exit();
        } else {
            $message = "Incorrect password!";
        }
    } else {
        $message = "No admin found with this email!";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Admin Login</title>
    <link rel="stylesheet" href="admin_style.css">
</head>
<body class="center-screen">
<div class="login-card">
    <h2>Admin Login</h2>

    <form method="POST">
        <input type="email" name="email" placeholder="Email" required><br>
        <input type="password" name="password" placeholder="Password" required>

        <button type="submit">Login</button>
    </form>

    <p class="error"><?php echo $message; ?></p>
</div>
</body>
</html>
