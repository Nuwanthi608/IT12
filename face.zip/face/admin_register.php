<?php
include "db_connect.php";

$msg = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST["username"];
    $email = $_POST["email"];
    $password = password_hash($_POST["password"], PASSWORD_DEFAULT);

    $sql = "INSERT INTO admin_users (username, email, password)
            VALUES ('$username', '$email', '$password')";

    if ($conn->query($sql)) {
        echo "<script>
                alert('Admin added successfully!');
                window.location='admin_login.php';
              </script>";
    } else {
        $msg = "Error: " . $conn->error;
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Add Admin</title>
    <link rel="stylesheet" href="admin_style.css">
</head>
<body class="center-screen">
<div class="login-card">
    <h2>Add Admin</h2>

    <form method="POST">
        <input type="text" name="username" placeholder="Username" required><br>
        <input type="email" name="email" placeholder="Email" required><br>
        <input type="password" name="password" placeholder="Password" required>

        <button type="submit">Create Admin</button>
    </form>

    <p class="error"><?php echo $msg; ?></p>
</div>
</body>
</html>
