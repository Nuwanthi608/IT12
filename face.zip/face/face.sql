-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 16, 2025 at 09:36 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `face`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_users`
--

CREATE TABLE `admin_users` (
  `admin_id` int(10) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin_users`
--

INSERT INTO `admin_users` (`admin_id`, `username`, `email`, `password`) VALUES
(1, 'admin1', 'admin1@uni.com', '$2y$10$KQg0ZP/9H2CBqv2U2uGpaee67Kp/QM4gdgMoPGHppNgMlQ1RKXA0e'),
(2, 'admin2', 'admin2@uni.com', '$2y$10$KQg0ZP/9H2CBqv2U2uGpaee67Kp/QM4gdgMoPGHppNgMlQ1RKXA0e'),
(3, 'admin3', 'admin3@uni.com', '$2y$10$KQg0ZP/9H2CBqv2U2uGpaee67Kp/QM4gdgMoPGHppNgMlQ1RKXA0e'),
(4, 'admin4', 'admin4@uni.com', '$2y$10$KQg0ZP/9H2CBqv2U2uGpaee67Kp/QM4gdgMoPGHppNgMlQ1RKXA0e'),
(5, 'admin5', 'admin5@uni.com', '$2y$10$KQg0ZP/9H2CBqv2U2uGpaee67Kp/QM4gdgMoPGHppNgMlQ1RKXA0e'),
(6, 'admin6', 'admin6@uni.com', '$2y$10$vUVhv5oMV2N2BWcsvc86K.eMWEld6bnasmp7sg6JGDZNP5OlCPYyu');

-- --------------------------------------------------------

--
-- Table structure for table `department`
--

CREATE TABLE `department` (
  `dep_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `num_students` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `department`
--

INSERT INTO `department` (`dep_id`, `name`, `num_students`) VALUES
(1, 'Computer Science', 250),
(2, 'Information Technology', 200),
(3, 'Mechanical Engineering', 180),
(4, 'Civil Engineering', 160),
(5, 'Electrical Engineering', 170),
(6, 'Electronics Engineering', 150),
(7, 'Management Studies', 220),
(8, 'Test Dep Add', 99);

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `st_id` int(10) NOT NULL,
  `st_name` varchar(100) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(50) NOT NULL,
  `dep_id` int(10) NOT NULL,
  `dep_name` varchar(75) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`st_id`, `st_name`, `username`, `password`, `email`, `dep_id`, `dep_name`) VALUES
(1, 'test1', 'testname', '$2y$10$tilkPdl1054seETGho', 'test@sample.com', 8, 'Test Dep Add'),
(4, 'Vihanga Kithmina', 'kith123', '$2y$10$js3G24sh8dy8lS/wTC', 'vihanga@sample.com', 1, 'Computer Science'),
(5, 'test2', 'test2', '$2y$10$ivmBlCVpbxZwGe3gtp', 'test2@sample.com', 7, 'Management Studies'),
(6, 'sith', '', '$2y$10$3TIWPeaHUGgKiyKvzfLYHeEGPx1cZqMfm4nT2mIbqE6F09dQLPD.a', '', 0, ''),
(7, 'Sithu Adhikari', 'sithu123', '$2y$10$7hYAz8IrwL9ni9RfbKol5.RexRD.a.ood.ycJ4q.F0c0kVOjaMFOG', 'sithu@sample.com', 1, 'Computer Science');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_users`
--
ALTER TABLE `admin_users`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `department`
--
ALTER TABLE `department`
  ADD PRIMARY KEY (`dep_id`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`st_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_users`
--
ALTER TABLE `admin_users`
  MODIFY `admin_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `department`
--
ALTER TABLE `department`
  MODIFY `dep_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `st_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
