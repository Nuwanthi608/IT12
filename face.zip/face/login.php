<?php
include 'db_connect.php';
session_start();

$message = "";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $email = trim($_POST['email']);
    $password = trim($_POST['password']);

    // Query user by email
    $sql = "SELECT * FROM student WHERE email = '$email'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {

        $row = $result->fetch_assoc();

        // Verify password
        if (password_verify($password, $row['password'])) {

            // Set session values
            $_SESSION['st_id'] = $row['st_id'];
            $_SESSION['st_name'] = $row['st_name'];
            $_SESSION['email'] = $row['email'];

            // Popup success + redirect
            echo "<script>
                    alert('Login Successful!');
                    window.location.href='dashboard.php';
                  </script>";
            exit;

        } else {
            $message = "Incorrect password!";
        }

    } else {
        $message = "No user found with this email!";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>Login — Face Recognition System</title>
  <link rel="stylesheet" href="login.css" />
  <link rel="stylesheet" href="index.css">
</head>
<body>
      <!-- Navigation Bar -->
    <nav class="navbar">
        <div class="nav-container">
            <div class="logo">FACE</div>
            <ul class="nav-menu">
                <li><a href="index.html" class="nav-link active">Home</a></li>
                <li><a href="login.php" class="nav-link">Login</a></li>
                <li><a href="register.php" class="nav-link">Register</a></li>
                <li><a href="dashboard.html" class="nav-link">Dashboard</a></li>
                <li><a href="capture.html" class="nav-link">Face Capture</a></li>
            </ul>
            <div class="hamburger">
                <span></span>
                <span></span>
                <span></span>
            </div>
        </div>
    </nav>

  <main class="page">
    <section class="visual">
      <div class="logo">FACE</div>
      <h1>Welcome Back</h1>
      <p class="lead">Sign in to manage captures, dashboards and events.</p>

      <div class="decor">
        <span class="dot a"></span>
        <span class="dot b"></span>
        <span class="dot c"></span>
      </div>
    </section>

    <section class="auth">
      <form id="loginForm" class="card" method="POST" action="" autocomplete="on" novalidate>
        <div class="card-head">
          <h2>Sign In</h2>
          <p class="muted">Use your account credentials</p>
        </div>

        <label class="field">
          <span class="label-text">Email</span>
          <input id="email" name="email" type="email" placeholder="you@example.com" required />
        </label>

        <label class="field">
          <span class="label-text">Password</span>
          <div class="pw-wrap">
            <input id="password" name="password" type="password" placeholder="Enter password" required />
            <button type="button" class="pw-toggle" aria-label="Show password">👁️</button>
          </div>
        </label>

        <button type="submit" class="btn primary">Sign in</button>

        <p class="signup">Don't have an account? <a href="register.php">Register</a></p>

        <p class="message" style="color:red;"><?php echo $message; ?></p>

      </form>
    </section>
  </main>

      <!-- Footer -->
    <footer class="footer">
        <div class="footer-content">
            <p>&copy; 2025 Face Recognition System | All Rights Reserved</p>
            
        </div>
    </footer>

  <script>
    (function(){
      const pwToggle = document.querySelector('.pw-toggle');
      const pwInput = document.getElementById('password');

      pwToggle?.addEventListener('click', ()=> {
        const t = pwInput.type === 'password' ? 'text' : 'password';
        pwInput.type = t;
        pwToggle.textContent = t === 'text' ? '🙈' : '👁️';
      });
    })();
  </script>
</body>
</html>
