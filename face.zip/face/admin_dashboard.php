<?php
session_start();
if (!isset($_SESSION["admin_id"])) {
    header("Location: admin_login.php");
    exit();
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="admin_style.css">
    <style>
        /* ...existing code... */
        /* Dashboard image styling */
        .content {
            padding: 24px;
            max-width: 1100px;
            margin-left: 220px; /* keep space for sidebar */
        }
        .dashboard-image {
            display: block;
            width: 100%;
            max-width: 1000px;
            height: auto;
            border-radius: 8px;
            box-shadow: 0 6px 18px rgba(0,0,0,0.12);
            margin-top: 20px;
        }
        @media (max-width: 800px) {
            .content { margin-left: 0; padding: 16px; }
            .sidebar { position: relative; width: 100%; }
        }
        /* ...existing code... */
    </style>
</head>
<body>

<div class="sidebar">
    <h2>FACE ADMIN</h2>

    <a href="admin_dashboard.php">Dashboard</a>
    <a href="admin_register.php">Add Admin</a>
    <a href="#">Students </a>
    <a href="#">Attendance </a>
    <a href="#">Reports </a>
    <a href="logout.php" class="logout">Logout</a>
</div>

<div class="content">
    <h1>Welcome, <?php echo htmlspecialchars($_SESSION['username'] ?? 'Admin'); ?> 👋</h1>
    <p>This is your University Face Recognition System Admin Panel.</p>

    <!-- Inserted dashboard image -->
    <img
        src="https://www.smartsheet.com/sites/default/files/2023-03/IC-Student-Attendance-Tracker-Template.png"
        alt="Student Attendance Tracker Template"
        class="dashboard-image"
        loading="lazy"
    />
</div>

<script src="admin_script.js"></script>
</body>
</html>
```// filepath: