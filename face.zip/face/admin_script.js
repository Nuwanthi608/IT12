document.querySelectorAll('.sidebar a').forEach(link => {
    link.addEventListener('mouseover', () => {
        link.style.transform = "translateX(5px)";
    });

    link.addEventListener('mouseleave', () => {
        link.style.transform = "translateX(0)";
    });
});
